﻿."$PSScriptRoot\SQLAzureTools.ps1"

#-------------------------------------------------------------------------------------------------------#
#Subscription #1 

$alias = '<your alias>'
$subs = '<subscription name>'
$server = '<server name>'
$resourcegroup = '<resource group name>'
$rule_name = "<rule name>" 

Login-WithAzureMicrosoftAccount -subscription $subs -path_to_file $PSScriptRoot\$alias-azureprofile.json

Remove-SqlAzureFirewallRule -server $server -resourcegroup $resourcegroup -rule $rule_name 
#-------------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------------#
#Subscription #2 

# Add more subscriptions here as needed
#-------------------------------------------------------------------------------------------------------#


Write-Host "`n$line"
Write-Host "`n$line"
Read-Host "Press Enter to continue"