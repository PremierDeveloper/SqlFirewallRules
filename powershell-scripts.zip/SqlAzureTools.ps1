﻿function Remove-SqlAzureFirewallRule
{
	Param(
	  [string]$server,
      [string]$resourcegroup,
	  [string]$rule
	)

	Write-Host "Trying to locate firewall rule $rule"

	try
	{
        $found_rule = Get-AzureRmSqlServerFirewallRule -FirewallRuleName $rule -ResourceGroupName $resourcegroup -ServerName $server -ErrorAction SilentlyContinue

        if($found_rule)
		{
			Write-Host "YES:  rule $($found_rule."RuleName") [Start ip:$($found_rule."StartIpAddress")] [End ip:$($found_rule."EndIpAddress")] was found... removing this rule."
			Write-Host "REMOVE:  removing rule $rule [Start ip:$($found_rule."StartIpAddress")] [End ip:$($found_rule."EndIpAddress")]."
            Remove-AzureRmSqlServerFirewallRule -FirewallRuleName $rule -ResourceGroupName $resourcegroup -ServerName $server  | Out-Null
		}
		else
		{
			Write-Host "NO: rule $rule was not found."
		}
	}
	catch
	{
		 $Error[0].Exception
	}
}

function Add-SqlAzureFirewallRule
{
    Param(
	  [string]$server,
      [string]$resourcegroup,
	  [string]$rule,
      [string]$ip 
    )

    try
    {
        
        Remove-SqlAzureFirewallRule -server $server -resourcegroup $resourcegroup -rule $rule

        Write-Host "ADD:  adding new rule $rule [Start ip:$ip] [Start ip:$ip]."
        New-AzureRmSqlServerFirewallRule -ServerName $server -ResourceGroupName $resourcegroup -FirewallRuleName $rule -StartIpAddress $ip -EndIpAddress $ip | Out-Null

    }
    catch
    {
         $Error[0].Exception
    }
}

function Get-ExternalIpAddress
{
    Param(
        [string]$externalip_api
    )
    return (new-object System.Net.WebClient).DownloadString($externalip_api).Replace("""", "")
}

function Login-WithAzureMicrosoftAccount
{
    Param(
        [string]$subscription,
        [string]$path_to_file
    )

    if(Test-Path $path_to_file)
    {
        Select-AzureRmProfile -Path $path_to_file
        Set-AzureRmContext -SubscriptionName $subscription
    }
    else
    {
        Login-AzureRmAccount
        Save-AzureRmProfile -Path $path_to_file
    }
}

 #This function is not tested properly. The code below is provided for reference only. Test thoroughly before use #
function Login-WithAzureADAccount
{
    Param(
        [string]$subscription,
        [string]$username,
        [string]$password
    )
    
    $userName = $username
    $securePassword = ConvertTo-SecureString -String $password -AsPlainText -Force
    $cred = New-Object System.Management.Automation.PSCredential($userName, $securePassword)
    
    Add-AzureRmAccount -Credential $cred 
    
    Set-AzureRmContext -SubscriptionName $subscription
}


