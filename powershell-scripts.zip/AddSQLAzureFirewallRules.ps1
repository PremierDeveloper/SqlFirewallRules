﻿."$PSScriptRoot\SQLAzureTools.ps1"

$external_ip = Get-ExternalIpAddress 'https://api.ipify.org'

#-------------------------------------------------------------------------------------------------------#
#Subscription #1 

$alias = '<your alias>'
$subs = '<subscription name>'
$server = '<server name>'
$resourcegroup = '<resource group name>'
$rule_name = "<rule name>" #follow pattern: Upper Case; Initials, Temoprary, Usage. Example: HG-TEMPORARY-UNITTESTS #

Login-WithAzureMicrosoftAccount -subscription $subs -path_to_file $PSScriptRoot\$alias-azureprofile.json


Add-SqlAzureFirewallRule -server $server -resourcegroup $resourcegroup -rule $rule_name -ip $external_ip
#-------------------------------------------------------------------------------------------------------#

#-------------------------------------------------------------------------------------------------------#
#Subscription #2 

# Add more subscriptions here as needed
#-------------------------------------------------------------------------------------------------------#


Write-Host "`n$line"
Write-Host "`n$line"
Read-Host "Press Enter to continue"